PRO CRICKET — STREET TO STADIUM v2.0
========================================
Offline playable cricket prototype.

WINDOWS:
1. Extract this ZIP.
2. Double-click START PRO CRICKET.bat.
3. The game opens in your default browser.

FEATURES:
- 1, 2, 3 and 5-over matches
- Rookie, Pro and Legend difficulty
- Multiple fictional teams
- Batting choices: Defend, Drive, Loft
- Keyboard controls: 1, 2, 3, Space
- Score, wickets, target, run rate and ball-by-ball scorecard
- Local XP, wins, matches and best-score save
- No external game libraries

This package uses fictional teams and original prototype code.

COMMENTARY V3:
- Dynamic ball-by-ball commentator text
- Separate commentary for dots, singles, twos, fours, sixes and wickets
- Shot-specific commentary
- End-of-over summaries
- Chase-pressure commentary
- Match-ending commentary

PROGRESSION V4:
- 10 player levels based on XP
- Coin economy from match results
- XP Shop
- 10 fictional unlockable teams
- Bat shop with multiple bats
- Auction House with random discounted bats
- Selected bat is shown in the match brief


V5 FIX
- Fixed XP Shop navigation with robust delegated click handling.
- Shop buttons remain functional after every screen redraw.
- Team purchases, bat purchases, auction, back-to-menu, and home navigation use the same reliable action system.
- Gameplay shot buttons also use the reliable action system.


V6 SHOP FIX
- Fixed the actual XP Shop template buttons to use data-action handlers.
- Added a direct XP Shop click fallback after the home screen renders.
- Fixed team purchase, bat purchase, and auction buttons in the shop.
- Updated the visible build version to v6.0.


V7 OFFLINE ARCADE LEAGUE
- Original fast 2-over league gameplay inspired by the genre, not copied from Cricket League.
- Offline league with standings, points, wins/losses and three tiers.
- Original player cards with unlock costs and gameplay bonuses.
- Original stadium collection and selection.
- Swipe controls on touch devices: left Defend, right Drive, up Loft.
- Keyboard controls remain 1/2/3 and Space.
- Offline AI-style outcome system, XP, coins and progression.
- All content is fictional/original.


V8 XP SHOP FIX
- Fixed the XP Shop button in the v7 Offline League build.
- Added a dedicated XP Shop button binding that works with mouse and touch.
- Shop navigation is rebound whenever the home screen is rendered.
- Existing offline league, player, stadium, XP and coin systems are preserved.
