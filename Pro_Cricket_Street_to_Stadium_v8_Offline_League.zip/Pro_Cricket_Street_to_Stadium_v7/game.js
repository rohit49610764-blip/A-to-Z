const $=s=>document.querySelector(s);
let S=JSON.parse(localStorage.getItem('pc2')||'null')||{
screen:'home',sound:true,matches:0,wins:0,xp:0,best:0,coins:500,
level:1,ownedTeams:['Kathmandu Comets'],ownedBats:['Street Starter'],
selectedBat:'Street Starter',
setup:{overs:2,diff:'Pro',team:'Kathmandu Comets',opp:'Pokhara Falcons'},
auction:{next:0,last:''}
};
S.coins??=500;S.level??=Math.min(10,1+Math.floor(S.xp/100));S.ownedTeams??=['Kathmandu Comets'];S.ownedBats??=['Street Starter'];S.selectedBat??='Street Starter';
S.ownedPlayers??=['Aarav Thapa'];S.selectedPlayer??='Aarav Thapa';
S.stadiums??=['Kathmandu Night'];S.selectedStadium??='Kathmandu Night';
S.league??={tier:1,points:0,wins:0,losses:0,played:0};
S.swipe??={x:0,y:0};
function save(){localStorage.setItem('pc2',JSON.stringify(S))}
S.version=8;refreshLevel();
function esc(x){return String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function shell(x){
  const screen=$('#screen');
  screen.innerHTML=x;
  $('#sound').textContent=S.sound?'🔊 Sound':'🔇 Muted';
}

const TEAMS=[
 ['Kathmandu Comets',0,'Starting team'],
 ['Pokhara Falcons',250,'Mountain attack'],
 ['Lalitpur Legends',500,'Technical batting'],
 ['Biratnagar Blazers',800,'Power hitters'],
 ['Chitwan Chargers',1100,'Fast starters'],
 ['Dhangadhi Dynamos',1500,'Aggressive squad'],
 ['Himalayan Hawks',2000,'Elite challenge team'],
 ['Terai Titans',2600,'All-round specialists'],
 ['Everest Eagles',3300,'Stadium giants'],
 ['Nepal Warriors',4200,'Legendary fictional club']
];
const BATS=[
 ['Street Starter',0,'Balanced'],
 ['Power Edge',200,'+Power'],
 ['Cannon Blade',450,'+Boundary chance'],
 ['Sky Master',800,'+Loft control'],
 ['Pro Carbon',1300,'Premium'],
 ['Thunder X',1900,'Elite power'],
 ['Golden Willow',2700,'Legendary']
];
function level(){return Math.min(10,1+Math.floor(S.xp/100))}
function refreshLevel(){S.level=level()}
function unlockTeam(i){
 const t=TEAMS[i];refreshLevel();
 if(S.ownedTeams.includes(t[0])) return alert('You already own '+t[0]+'.');
 if(S.coins<t[1]) return alert('Not enough coins. Win matches and use the auction.');
 if(S.level < Math.min(10,Math.max(1,Math.ceil((i+1)/2)))) return alert('Reach a higher level to unlock this team.');
 S.coins-=t[1];S.ownedTeams.push(t[0]);save();shop();
}
function buyBat(i){
 const b=BATS[i];
 if(S.ownedBats.includes(b[0])) return alert('You already own this bat.');
 if(S.coins<b[1]) return alert('Not enough coins.');
 S.coins-=b[1];S.ownedBats.push(b[0]);S.selectedBat=b[0];save();shop();
}
function auction(){
 const candidates=BATS.filter(b=>!S.ownedBats.includes(b[0]));
 if(!candidates.length)return alert('You already own every bat.');
 const b=candidates[Math.floor(Math.random()*candidates.length)];
 const base=b[1], price=Math.max(50,Math.round(base*(.55+Math.random()*.35)));
 S.auction={next:b[0],last:`${b[0]} is on auction for ${price} coins.`};
 const ok=confirm(`🎙️ AUCTION\\n\\n${b[0]}\\n${b[2]}\\n\\nCurrent bid: ${price} coins\\n\\nBuy it?`);
 if(ok){
   if(S.coins<price)return alert('You do not have enough coins for this bid.');
   S.coins-=price;S.ownedBats.push(b[0]);S.selectedBat=b[0];S.auction.last=`Won ${b[0]} for ${price} coins!`;save();
 } else {S.auction.last='Auction passed.';save();}
 shop();
}

const PLAYERS=[
 ['Aarav Thapa',0,'Balanced opener','Control'],
 ['Rohan Gurung',250,'Timing specialist','Control +1'],
 ['Suman Rai',450,'Power hitter','Power +1'],
 ['Nischal Karki',700,'Loft expert','Loft +1'],
 ['Bibek Shrestha',1000,'Fast scorer','Power +1'],
 ['Kiran Magar',1400,'Boundary hunter','Power +2'],
 ['Prabin KC',1900,'All-round star','Control +2'],
 ['Roshan Tamang',2500,'Elite finisher','Power +2'],
 ['Aayush Bista',3200,'League captain','Control +2'],
 ['Samir Lama',4000,'Stadium legend','Power +3']
];
const STADIUMS=[
 ['Kathmandu Night',0,'City lights'],
 ['Pokhara Valley',600,'Mountain backdrop'],
 ['Lalitpur Arena',1200,'Fast outfield'],
 ['Terai Dome',2000,'Big boundary'],
 ['Everest Park',3200,'Championship ground']
];
const LEAGUES=[
 ['Street League',0,6],['Pro League',3,8],['Champions League',6,10]
];
function playerBonus(){
 const p=PLAYERS.find(x=>x[0]===S.selectedPlayer)||PLAYERS[0];
 return p[3].includes('Power +3')?.12:p[3].includes('Power +2')?.08:p[3].includes('Power +1')?.04:0;
}
function leagueScreen(){
 const names=['Kathmandu Comets','Pokhara Falcons','Lalitpur Legends','Biratnagar Blazers','Chitwan Chargers','Dhangadhi Dynamos','Himalayan Hawks','Terai Titans'];
 const points=S.league.points||0, tier=S.league.tier||1;
 shell(`<section class="card"><div class="muted">OFFLINE LEAGUE</div><h1>${LEAGUES[tier-1][0]}</h1><p class="muted">No internet required. Play quick 2-over matches and climb the original offline league.</p>
 <div class="leagueHero"><div><b>League Progress</b><div class="progress"><i style="width:${Math.min(100,(points%30)/30*100)}%"></i></div><small>${points%30}/30 points</small></div><div class="stat"><small>Record</small><b>${S.league.wins}-${S.league.losses}</b></div></div>
 <h2>🏆 Standings</h2><table class="table"><tr><th>#</th><th>Club</th><th>Pts</th></tr>${names.map((n,i)=>{let pts=i===0?points:Math.max(0,18-i*2+(i===tier?4:0));return `<tr><td>${i+1}</td><td>${n}</td><td>${pts}</td></tr>`}).join('')}</table>
 <div class="buttons"><button class="primary" data-action="league-match">Play League Match</button><button class="secondary" data-action="home">Back</button></div></section>`);
}
function collectionScreen(){
 refreshLevel();
 shell(`<section class="card"><div class="muted">MY SQUAD</div><h1>Players & Stadiums</h1>
 <h2>👤 Player Cards</h2><div class="shopgrid">${PLAYERS.map((p,i)=>{let own=S.ownedPlayers.includes(p[0]);return `<div class="shopitem"><b>${p[0]}</b><small>${p[2]}</small><span>🪙 ${p[1]} • ${p[3]}</span><button class="${own?'secondary':'primary'}" ${own?'':'data-action="buy-player" data-index="'+i+'"'}>${own?(S.selectedPlayer===p[0]?'Selected':'Select'):'Unlock'}</button></div>`}).join('')}</div>
 <h2 style="margin-top:25px">🏟️ Stadiums</h2><div class="shopgrid">${STADIUMS.map((st,i)=>{let own=S.stadiums.includes(st[0]);return `<div class="shopitem"><b>${st[0]}</b><small>${st[2]}</small><span>🪙 ${st[1]}</span><button class="${own?'secondary':'primary'}" ${own?'':'data-action="buy-stadium" data-index="'+i+'"'}>${own?(S.selectedStadium===st[0]?'Selected':'Select'):'Unlock'}</button></div>`}).join('')}</div>
 <div class="buttons" style="margin-top:18px"><button class="secondary" data-action="home">Back to Menu</button></div></section>`);
}
function buyPlayer(i){
 const p=PLAYERS[i];
 if(S.ownedPlayers.includes(p[0])){S.selectedPlayer=p[0];save();collectionScreen();return}
 const req=Math.min(10,Math.max(1,Math.ceil((i+1)/2)));
 if(S.level<req)return alert('Reach level '+req+' to unlock this player.');
 if(S.coins<p[1])return alert('Not enough coins.');
 S.coins-=p[1];S.ownedPlayers.push(p[0]);S.selectedPlayer=p[0];save();collectionScreen();
}
function buyStadium(i){
 const st=STADIUMS[i];
 if(S.stadiums.includes(st[0])){S.selectedStadium=st[0];save();collectionScreen();return}
 if(S.level<Math.min(10,i+1))return alert('Reach a higher level to unlock this stadium.');
 if(S.coins<st[1])return alert('Not enough coins.');
 S.coins-=st[1];S.stadiums.push(st[0]);S.selectedStadium=st[0];save();collectionScreen();
}


function bindXPShopButton(){
  const b=document.getElementById('xpShopBtn');
  if(!b || b.dataset.bound==='1') return;
  b.dataset.bound='1';
  const openShop=(ev)=>{ev.preventDefault();shop();};
  b.addEventListener('click',openShop);
  b.addEventListener('touchend',openShop,{passive:false});
}

function shop(){
 refreshLevel();S.screen='shop';save();
 shell(`<section class="card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><div class="muted">XP SHOP</div><h1>Build your club.</h1><p class="muted">Spend coins on fictional teams and bats. Level up through match XP.</p></div><div class="stat"><small>Coins</small><b>🪙 ${S.coins}</b></div></div>
 <div class="stats"><div class="stat"><small>Level</small><b>${S.level}/10</b></div><div class="stat"><small>XP</small><b>${S.xp}</b></div><div class="stat"><small>Teams</small><b>${S.ownedTeams.length}/10</b></div><div class="stat"><small>Bats</small><b>${S.ownedBats.length}/${BATS.length}</b></div></div>
 <h2 style="margin-top:25px">🏟️ Teams</h2><div class="shopgrid">${TEAMS.map((t,i)=>{let own=S.ownedTeams.includes(t[0]);let req=Math.min(10,Math.max(1,Math.ceil((i+1)/2)));return `<div class="shopitem"><b>${t[0]}</b><small>${t[2]}</small><span>🪙 ${t[1]} • Level ${req}</span><button class="${own?'secondary':'primary'}" ${own?'disabled':''} data-action="unlock-team" data-index="${i}">${own?'Owned':'Buy Team'}</button></div>`}).join('')}</div>
 <h2 style="margin-top:25px">🏏 Bat Shop</h2><div class="shopgrid">${BATS.map((b,i)=>{let own=S.ownedBats.includes(b[0]);return `<div class="shopitem"><b>${b[0]}</b><small>${b[2]}</small><span>🪙 ${b[1]}</span><button class="${own?'secondary':'primary'}" ${own?'disabled':''} data-action="buy-bat" data-index="${i}">${own?'Owned':'Buy Bat'}</button></div>`}).join('')}</div>
 <h2 style="margin-top:25px">🔨 Auction House</h2><div class="auction"><p class="muted">A random unowned bat appears with a discounted bid. Win it if you have enough coins.</p><button class="primary" data-action="auction">Start Auction</button><p>${esc(S.auction.last||'No auction yet.')}</p></div>
 <div class="buttons" style="margin-top:18px"><button class="secondary" data-action="home">Back to Menu</button></div></section>`);
}

function home(){S.screen='home';save();shell(`<section class="card hero"><div><div class="muted">OFFLINE PLAYABLE BUILD</div><h1>Own the crease.<br>Rule the stadium.</h1><p class="muted">Fast 2-over arcade cricket with offline leagues, player cards, stadiums and swipe batting.</p><div class="buttons"><button class="primary" data-action="setup">Start Match</button><button class="secondary" data-action="how">How to Play</button><button class="secondary" id="xpShopBtn" type="button">XP Shop</button><button class="secondary" data-action="league">Offline League</button><button class="secondary" data-action="squad">My Squad</button></div></div><div class="art"><div class="ball"></div><span>Every ball is a decision.</span></div></section><section class="card" style="margin-top:16px"><h2>Your Progress</h2><div class="stats"><div class="stat"><small>Matches</small><b>${S.matches}</b></div><div class="stat"><small>Wins</small><b>${S.wins}</b></div><div class="stat"><small>XP</small><b>${S.xp}</b></div><div class="stat"><small>Best Score</small><b>${S.best}</b></div></div></section>`);
  bindXPShopButton();
}
function setup(){S.screen='setup';save();shell(`<section class="card"><h2>Match Setup</h2><p class="muted">Configure your quick match.</p><div class="fields"><div class="field"><label>Overs</label><select id="o"><option>1</option><option selected>2</option><option>3</option><option>5</option></select></div><div class="field"><label>Difficulty</label><select id="d"><option>Rookie</option><option selected>Pro</option><option>Legend</option></select></div><div class="field"><label>Your Team</label><select id="t"><option>Kathmandu Comets</option><option>Lalitpur Legends</option><option>Biratnagar Blazers</option></select></div><div class="field"><label>Opponent</label><select id="op"><option>Pokhara Falcons</option><option>Chitwan Chargers</option><option>Dhangadhi Dynamos</option></select></div></div><div class="buttons" style="margin-top:18px"><button class="secondary" data-action="home">Back</button><button class="primary" onclick="begin()">Play Now</button></div></section>`) }

function leagueMatch(){
 if((S.level||1)<LEAGUES[(S.league.tier||1)-1][1]) return alert('Reach the required level to enter this league.');
 const opponents=['Pokhara Falcons','Lalitpur Legends','Biratnagar Blazers','Chitwan Chargers','Dhangadhi Dynamos'];
 const opp=opponents[Math.floor(Math.random()*opponents.length)];
 S.setup={overs:2,diff:(S.league.tier||1)>=3?'Legend':'Pro',team:S.setup.team||'Kathmandu Comets',opp};
 const target=10+Math.floor(Math.random()*10)+(S.league.tier-1)*3;
 S.m={ball:0,score:0,w:0,target,feed:[`League match vs ${opp}. Target ${target}.`],events:[],league:true};
 S.screen='match';save();match();
}

function begin(){let o=+$('#o').value,d=$('#d').value;S.setup={overs:o,diff:d,team:$('#t').value,opp:$('#op').value};let mult=d==='Legend'?1.12:d==='Rookie'?.82:1;let target=Math.max(7,Math.round(o*6*mult+Math.random()*6));S.m={ball:0,score:0,w:0,target,feed:[`Target set at ${target}. The chase begins.`],events:[]};S.screen='match';save();match()}

const commentary = {
  dot: [
    "Dot ball. Excellent discipline from the bowler.",
    "Beaten for pace — no run.",
    "Good length and defended safely.",
    "Tight bowling. The batter can't find the gap.",
    "A quiet ball. The fielding side will be happy with that."
  ],
  one: [
    "Worked into the gap for a single.",
    "Quick running between the wickets — one run.",
    "Nudged away nicely for a single.",
    "Easy single. Good strike rotation."
  ],
  two: [
    "Good placement — they'll come back for two.",
    "Driven into the space and they pick up two.",
    "Excellent running. Two more to the total."
  ],
  four: [
    "FOUR! Crunched away with real authority!",
    "That's a boundary! Beautifully timed through the gap.",
    "FOUR! The fielders had no chance.",
    "What a shot! It races away for four!"
  ],
  six: [
    "SIX! That's gone a long way!",
    "Into the stands! What a strike!",
    "Huge hit — SIX! The crowd would be loving that.",
    "Maximum! Cleanly struck over the boundary."
  ],
  wicket: [
    "WICKET! The pressure finally tells!",
    "Gone! A big moment in the match.",
    "WICKET! The bowler wins the battle.",
    "That's out! The batting side loses a wicket."
  ],
  defend: [
    "Solid defense. The batter watches it closely.",
    "Straight bat, soft hands — safely defended.",
    "Good judgment. No need to play at that one."
  ],
  loft: [
    "The batter decides to attack the ball in the air.",
    "That's an aggressive option — the field is under pressure.",
    "Going aerial here. High risk, high reward."
  ]
};
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function makeCommentary(shot, r, w, m){
  if(w) return pick(commentary.wicket);
  if(r===6) return pick(commentary.six);
  if(r===4) return pick(commentary.four);
  if(r===2) return pick(commentary.two);
  if(r===1) return pick(commentary.one);
  if(shot==="Defend") return pick(commentary.defend);
  if(shot==="Loft") return pick(commentary.loft);
  return pick(commentary.dot);
}
function pressureLine(m){
  const need=Math.max(0,m.target-m.score);
  if(need===0) return "The target is reached! What a finish!";
  if(need<=3 && m.ball < S.setup.overs*6) return "Just a few runs needed now — the pressure is on!";
  if(m.w===2) return "Two wickets down. Every delivery matters from here.";
  if(m.ball>=S.setup.overs*6-2 && need>0) return "Final deliveries! The chase is going down to the wire.";
  return null;
}

function outcome(shot){let r=Math.random(),p=S.setup.diff==='Legend'?.06:S.setup.diff==='Rookie'?-.04:0;if(shot==='Defend'){if(r<.87+p)return[0,0,'Solid defense.'];if(r<.96+p)return[1,0,'Quick single.'];return[0,1,'Edge — wicket!']}if(shot==='Drive'){if(r<.20+p)return[0,1,'Mistimed drive — wicket!'];if(r<.53+p)return[1,0,'Driven for one.'];if(r<.80+p)return[2,0,'Beautiful drive for two.'];if(r<.95+p)return[4,0,'Cracked away for FOUR!'];return[6,0,'Perfect timing — SIX!']}if(r<.28+p)return[0,1,'Big swing — wicket!'];if(r<.46+p)return[1,0,'Top edge, one run.'];if(r<.65+p)return[2,0,'Lofted for two.'];if(r<.83+p)return[4,0,'Clears the infield — FOUR!'];return[6,0,'Into the stands — SIX!']}
function shot(sh){
  let m=S.m;if(!m||m.done)return;
  let [r,w,text]=outcome(sh);
  m.ball++;m.score+=r;m.w+=w;
  let line=makeCommentary(sh,r,w,m);
  m.events.push([m.ball,r,w]);
  m.feed.unshift(`Ball ${m.ball}: ${line}`);
  if(m.ball%6===0){
    const overNo=Math.ceil(m.ball/6);
    const overRuns=m.events.slice(Math.max(0,m.events.length-6)).reduce((a,e)=>a+e[1],0);
    m.feed.unshift(`OVER ${overNo}: ${overRuns} run${overRuns===1?'':'s'} from the over. Score ${m.score}/${m.w}.`);
  }
  const pressure=pressureLine(m);
  if(pressure)m.feed.unshift(`COMMENTATOR: ${pressure}`);
  if(m.score>=m.target||m.w>=3||m.ball>=S.setup.overs*6){
    m.done=true;
    if(m.score>=m.target)m.feed.unshift("COMMENTATOR: What a chase! The target has been reached.");
    else if(m.w>=3)m.feed.unshift("COMMENTATOR: All three wickets are down. The innings is over.");
    else m.feed.unshift("COMMENTATOR: That's the end of the innings.");
    S.matches++;if(m.score>=m.target)S.wins++;
    if(m.league){S.league.played++;if(m.score>=m.target){S.league.wins++;S.league.points+=3}else{S.league.losses++;}if(S.league.points>=30 && S.league.tier<3){S.league.tier++;S.league.points=0}}
    S.xp+=(m.score>=m.target?50:15)+m.score;S.coins+=(m.score>=m.target?150:50)+m.score*2;refreshLevel();S.best=Math.max(S.best,m.score);
    S.screen='result';save();result();
  }else{save();match()}
}
function match(){let m=S.m,ov=`${Math.floor(m.ball/6)}.${m.ball%6}`,need=Math.max(0,m.target-m.score);shell(`<div class="grid"><section class="card"><div class="score"><div><small class="muted">${esc(S.setup.team)}</small><div>CHASING</div></div><strong>${m.score}/${m.w}</strong><div>Target<br><b>${m.target}</b></div></div><div class="stats"><div class="stat"><small>Overs</small><b>${ov}/${S.setup.overs}.0</b></div><div class="stat"><small>Need</small><b>${need}</b></div><div class="stat"><small>Wickets</small><b>${3-m.w}</b></div><div class="stat"><small>Rate</small><b>${m.ball?(m.score/(m.ball/6)).toFixed(2):'0.00'}</b></div></div><div class="pitch"><div class="strip"></div><div class="redball"></div><div class="bat"></div></div><div class="swipeHint">Swipe <b>←</b> Defend · <b>→</b> Drive · <b>↑</b> Loft</div><div class="shots"><button class="shot" data-action="shot" data-shot="Defend">1 · Defend<small>Safe</small></button><button class="shot" data-action="shot" data-shot="Drive">2 · Drive<small>Balanced</small></button><button class="shot" data-action="shot" data-shot="Loft">3 · Loft<small>Risky</small></button></div><div class="feed"><div style="color:#62e6a4;font-weight:800;margin-bottom:7px">🎙️ LIVE COMMENTARY</div>${m.feed.slice(0,10).map(esc).map(x=>`<div>${x}</div>`).join('')}</div></section><aside class="card"><h3>Match Brief</h3><p class="muted">${esc(S.setup.team)} vs ${esc(S.setup.opp)}</p><p class="muted">👤 Player: ${esc(S.selectedPlayer)}</p><p class="muted">🏏 Bat: ${esc(S.selectedBat)}</p><p class="muted">🏟️ ${esc(S.selectedStadium)}</p><p class="muted">${S.setup.overs} overs • ${esc(S.setup.diff)} difficulty</p><button class="secondary" data-action="home">Quit Match</button></aside></div>`)}
function result(){let m=S.m,win=m.score>=m.target;shell(`<div class="grid"><section class="card"><div class="muted">${win?'VICTORY':'MATCH COMPLETE'}</div><h1>${win?'Chase complete!':'The chase falls short.'}</h1><p class="muted">${esc(S.setup.team)} ${m.score}/${m.w} — target ${m.target}</p><div class="stats"><div class="stat"><small>Score</small><b>${m.score}</b></div><div class="stat"><small>Target</small><b>${m.target}</b></div><div class="stat"><small>XP</small><b>${(win?50:15)+m.score}</b></div><div class="stat"><small>Matches</small><b>${S.matches}</b></div></div><div class="buttons" style="margin-top:18px"><button class="primary" data-action="setup">Play Again</button><button class="secondary" data-action="home">Main Menu</button></div></section><aside class="card"><h3>Scorecard</h3><table class="table"><tr><th>Ball</th><th>Runs</th><th>Event</th></tr>${m.events.map(e=>`<tr><td>${e[0]}</td><td>${e[2]?'W':e[1]}</td><td>${e[2]?'Wicket':e[1]===6?'Six':e[1]===4?'Four':e[1]?'Runs':'Dot'}</td></tr>`).join('')}</table></aside></div>`)}

$('#screen').addEventListener('click',e=>{
  const btn=e.target.closest('[data-action]');
  if(!btn) return;
  const action=btn.dataset.action;
  if(action==='shop'){shop();return;}
  if(action==='setup'){setup();return;}
  if(action==='home'){home();return;}
  if(action==='how'){
    alert('Choose a shot for every ball. 1 = Defend, 2 = Drive, 3 = Loft, Space = Drive. Reach the target before 3 wickets or the over limit.');
    return;
  }
  if(action==='unlock-team'){unlockTeam(Number(btn.dataset.index));return;}
  if(action==='buy-bat'){buyBat(Number(btn.dataset.index));return;}
  if(action==='auction'){auction();return;}
  if(action==='league'){leagueScreen();return;}
  if(action==='league-match'){leagueMatch();return;}
  if(action==='squad'){collectionScreen();return;}
  if(action==='buy-player'){buyPlayer(Number(btn.dataset.index));return;}
  if(action==='buy-stadium'){buyStadium(Number(btn.dataset.index));return;}
  if(action==='shot'){shot(btn.dataset.shot);return;}
  if(action==='play-again'){setup();return;}
});

document.addEventListener('keydown',e=>{if(S.screen==='match'){if(e.key==='1')shot('Defend');if(e.key==='2'||e.code==='Space'){e.preventDefault();shot('Drive')}if(e.key==='3')shot('Loft')}})
$('#sound').onclick=()=>{S.sound=!S.sound;save();$('#sound').textContent=S.sound?'🔊 Sound':'🔇 Muted'}
home();
const shopButton=document.querySelector('[data-action="shop"]');
if(shopButton) shopButton.addEventListener('click',shop);

let touchStart=null;
$('#screen').addEventListener('touchstart',e=>{
 if(S.screen!=='match')return;
 const t=e.changedTouches[0];touchStart={x:t.clientX,y:t.clientY};
},{passive:true});
$('#screen').addEventListener('touchend',e=>{
 if(S.screen!=='match'||!touchStart)return;
 const t=e.changedTouches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;
 touchStart=null;
 if(Math.max(Math.abs(dx),Math.abs(dy))<30)return;
 if(Math.abs(dx)>Math.abs(dy))shot(dx<0?'Defend':'Drive');else if(dy<0)shot('Loft');else shot('Defend');
},{passive:true});

window.addEventListener('DOMContentLoaded',()=>setTimeout(bindXPShopButton,0));
